<?php
/**
 * Plugin Name: Voseda Form Hardcode Helper
 * Description: Funciones helper para incrustar formularios en cualquier parte del tema
 * Version: 1.0.0
 * Author: IMaaS Group
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Renderizar formulario de contacto
 * Uso en template: <?php voseda_render_contact_form(); ?>
 */
function voseda_render_contact_form($form_id = null) {
    // Detectar qué plugin de formularios está activo

    // Opción 1: Contact Form 7
    if (function_exists('wpcf7_contact_form')) {
        $default_form_id = $form_id ?: '78a0090'; // ID del formulario de Voseda
        echo do_shortcode("[contact-form-7 id=\"{$default_form_id}\" title=\"Formulario contacto\"]");
        return;
    }

    // Opción 2: WPForms
    if (function_exists('wpforms')) {
        $default_form_id = $form_id ?: 1; // Cambiar por tu ID real
        echo do_shortcode("[wpforms id=\"{$default_form_id}\"]");
        return;
    }

    // Opción 3: Gravity Forms
    if (class_exists('GFForms')) {
        $default_form_id = $form_id ?: 1; // Cambiar por tu ID real
        gravity_form($default_form_id, true, true, false, '', true);
        return;
    }

    // Opción 4: Ninja Forms
    if (class_exists('Ninja_Forms')) {
        $default_form_id = $form_id ?: 1; // Cambiar por tu ID real
        echo do_shortcode("[ninja_form id=\"{$default_form_id}\"]");
        return;
    }

    // Fallback: Formulario HTML personalizado
    voseda_render_custom_form();
}

/**
 * Formulario HTML personalizado como fallback
 */
function voseda_render_custom_form() {
    ?>
    <form id="voseda-contact-form" class="voseda-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="voseda_contact_form">
        <?php wp_nonce_field('voseda_contact_form', 'voseda_nonce'); ?>

        <div class="form-group">
            <label for="voseda_name">Nombre *</label>
            <input type="text" id="voseda_name" name="voseda_name" required>
        </div>

        <div class="form-group">
            <label for="voseda_email">Email *</label>
            <input type="email" id="voseda_email" name="voseda_email" required>
        </div>

        <div class="form-group">
            <label for="voseda_phone">Teléfono</label>
            <input type="tel" id="voseda_phone" name="voseda_phone">
        </div>

        <div class="form-group">
            <label for="voseda_message">Mensaje *</label>
            <textarea id="voseda_message" name="voseda_message" rows="5" required></textarea>
        </div>

        <button type="submit" class="voseda-submit-btn">Enviar Mensaje</button>
    </form>

    <style>
        .voseda-form { max-width: 600px; margin: 0 auto; }
        .voseda-form .form-group { margin-bottom: 1.5rem; }
        .voseda-form label { display: block; margin-bottom: 0.5rem; font-weight: 600; }
        .voseda-form input, .voseda-form textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .voseda-submit-btn {
            background: var(--voseda-primary, #ff6b6b);
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
        }
        .voseda-submit-btn:hover { opacity: 0.9; }
    </style>
    <?php
}

/**
 * Procesar formulario personalizado
 */
add_action('admin_post_voseda_contact_form', 'voseda_process_contact_form');
add_action('admin_post_nopriv_voseda_contact_form', 'voseda_process_contact_form');

function voseda_process_contact_form() {
    // Verificar nonce
    if (!isset($_POST['voseda_nonce']) || !wp_verify_nonce($_POST['voseda_nonce'], 'voseda_contact_form')) {
        wp_die('Error de seguridad');
    }

    // Sanitizar datos
    $name = sanitize_text_field($_POST['voseda_name']);
    $email = sanitize_email($_POST['voseda_email']);
    $phone = sanitize_text_field($_POST['voseda_phone']);
    $message = sanitize_textarea_field($_POST['voseda_message']);

    // Email de notificación
    $to = get_option('admin_email'); // O hardcodea: 'contacto@voseda.com'
    $subject = "Nuevo mensaje de contacto desde Voseda.com";
    $body = "
        Nombre: {$name}\n
        Email: {$email}\n
        Teléfono: {$phone}\n
        Mensaje:\n{$message}
    ";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        "Reply-To: {$email}"
    );

    // Enviar email
    $sent = wp_mail($to, $subject, $body, $headers);

    // Redirigir
    if ($sent) {
        wp_redirect(add_query_arg('form_sent', '1', wp_get_referer()));
    } else {
        wp_redirect(add_query_arg('form_error', '1', wp_get_referer()));
    }
    exit;
}

/**
 * Shortcode para usar en el editor de WordPress
 * Uso: [voseda_form]
 */
add_shortcode('voseda_form', 'voseda_form_shortcode');

function voseda_form_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => null,
    ), $atts);

    ob_start();
    voseda_render_contact_form($atts['id']);
    return ob_get_clean();
}

/**
 * Widget de formulario para Gutenberg
 */
add_action('init', 'voseda_register_form_block');

function voseda_register_form_block() {
    if (!function_exists('register_block_type')) {
        return;
    }

    // Registrar bloque simple (requiere WordPress 5.0+)
    // Para uso avanzado, considera crear con @wordpress/create-block
}
